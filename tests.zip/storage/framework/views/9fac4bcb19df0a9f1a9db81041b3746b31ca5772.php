<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
        <meta name="description" content="" />
        <meta name="author" content="" />
        <title><?php echo $__env->yieldContent('title'); ?></title>
        <link href="/admin/css/styles.css" rel="stylesheet" />
        <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/js/all.min.js" crossorigin="anonymous"></script>
        <script src="/angular.min.js"></script>
        <script src="/admin/js/scripts.js"></script>



        <script src="https://cdn.ckeditor.com/ckeditor5/34.0.0/classic/ckeditor.js"></script>
    </head>
    <body>
      <?php echo $__env->make('admin/layout/admin-navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div id="layoutSidenav">
          <?php echo $__env->make('admin/layout/admin-sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <div id="layoutSidenav_content">
                <main>
                    <div class="container-fluid px-4">

                    <h1 class="mt-4"><?php echo $__env->yieldContent('page-title'); ?></h1>
                    <?php echo $__env->yieldContent('main-content'); ?>
                    </div>
                </main>
               <?php echo $__env->make('admin/layout/admin-footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
        </div>
        <script src="/admin/js/bootstrap.bundle.min.js" crossorigin="anonymous"></script>
    <?php echo $__env->yieldContent('scripts'); ?>
    </body>
</html>
<?php /**PATH E:\xampp\htdocs\Laravel\WebShop\resources\views/admin/layout/admin-layout.blade.php ENDPATH**/ ?>