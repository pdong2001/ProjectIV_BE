
<?php $__env->startSection('title'); ?>
    Trang chủ
<?php $__env->stopSection(); ?>
<?php $__env->startSection('page-title'); ?>
    Trang chủ
<?php $__env->stopSection(); ?>
<?php $__env->startSection('main-content'); ?>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin/layout/admin-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\Laravel\WebShop\resources\views/admin/pages/home.blade.php ENDPATH**/ ?>